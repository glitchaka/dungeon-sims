# Probar la alpha

Abre **Jugar.exe** con doble clic, en el proyecto o en el ZIP extraido. Es un lanzador grafico y el juego usa el subsistema Windows: no mantiene una consola CMD. Jugar.bat y Jugar-Alpha.bat solo delegan en ese lanzador y terminan. Jugar.vbs es otro acceso sin consola. Para desarrollo se conserva tools/run_native.ps1, que compila; Jugar.bat ya no compila al abrir una partida.

La primera pantalla pide nombre y perfil de guardado; permite jugar individualmente, abrir una partida o conectar a una IPv4. Muestra la direccion local del anfitrion y permite copiarla. Se puede continuar una partida o marcar Nueva isla. Si no existe partida, se genera una isla por semilla. Un reinicio deliberado conserva la partida v8 previa como .bak.

## Jugador y habitantes

Clic inspecciona. El jugador puede inspirar sustento, edificacion, diplomacia o saqueo; enviar lluvia; sanar; dejar un regalo; anunciar el elegido. El regalo ocupa espacio y se recoge desde fuera. El elegido nace tras 270 dias de juego, no inmediatamente; el contador se guarda. Un dia son 300 segundos simulados.

Ahora tambien hay encargos de MUELLE, TOWNHALL y ALTAR: pulsa el boton y elige suelo adecuado. Se reservan recursos y el habitante seleccionado recibe el encargo, que puede interrumpir por necesidades o descanso. Otros trabajadores pueden retomarlo. No se crea un edificio instantaneo.

Muelle: 16 madera y 12 monedas, junto al mar; aporta un barco funcional. Townhall: 24 madera y 25 monedas; actua como nuevo centro civico y almacen. Altar: 8 madera y 10 monedas; mejora socializacion y animo cerca de el. Conservan tipo propio, colisiones y guardado. Ninguno cuenta como vivienda.

Los NPC deciden agricultura, tala, ampliacion de campos, viviendas, caminos y pesca. Por la noche interrumpen obras y vuelven a descansar; hambre/sed urgentes pueden despertarlos. Los viajeros ya embarcados terminan su travesia. El texto NOCHE y la simulacion usan el mismo reloj. La inspiracion de edificacion ya no obliga a trabajar toda la noche.

## Caminos y migracion

Las partidas nuevas no tienen una red de caminos inicial. El uso reciente crea encargos de caminos y el abandono crea encargos de retirada. Al importar archivos v6/v7 se retiran una sola vez los caminos antiguos y sus encargos obsoletos, conservando estructuras, habitantes y puentes necesarios. Los archivos originales se conservan. Los caminos construidos bajo v8 se guardan y no se borran en cada arranque.

## Controles y guardado

Espacio pausa; E cambia velocidad; Q lluvia; rueda zoom; central/WASD desplaza; Enter encuadra. CHAT abre escritura; Enter envia y Esc cierra. Mientras escribes, las teclas no ordenan mover la camara ni cambian el clima.

LOCALAPPDATA/IslaVivaNative contiene partidas v8 separadas por perfil. Se importa v7 y, para la partida individual antigua, v6. Conserva identidad, visitas pendientes, chat, edificios, alturas, semilla, geografia, ordenes y nacimiento elegido. Guardado manual, automatico y al cerrar. La importacion no mezcla las dos islas ni sus habitantes.

## Estado

Build Release y pruebas de simulacion, TCP real, chat, diplomacia/saqueo, deduplicacion, reconexion, guardado, islas por semilla, crecimiento, pendientes, obras y descanso nocturno. TERRENO.md describe geografia y arte. MULTIPLAYER.md describe conexion y alcance. El acabado visual aun esta en revision; no es una reproduccion aprobada de la isla de referencia.
