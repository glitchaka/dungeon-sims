@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File run_multiplayer.ps1 %*
if errorlevel 1 pause
